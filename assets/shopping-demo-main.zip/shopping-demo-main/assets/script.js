////nav bar
 //location
  //**assign to local storage for cart
 //name of site
 //cart (icon top right ish.. or link)
 
//body
 //products (look into using a bootstrap form )
  // button that adds product to cart.
  //description of product
  //**two rows of cards. 4-6 items (more if needed, not using a form)
//**store items in storage

