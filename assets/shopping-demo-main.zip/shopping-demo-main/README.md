# project1
group project 1

online shopping

***ADD NEW TECH***

//nav bar
 //location
  **assign to local storage for cart
 //name of site
 //cart (icon top right ish.. or link)
 
//body
 //products (look into using a bootstrap form )
  // button that adds product to cart.
  //description of product
  **two rows of cards. 4-6 items (more if needed, not using a form)
**store items in storage

//footer
 
**cart seperate page**
//display selected items
//form for customer shipping/payment info 
//use weather API to display weather and Est. shipping time.
    **after perchase, display "thank you message"
